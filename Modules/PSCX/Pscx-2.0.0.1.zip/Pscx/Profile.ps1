#region ----------- Beginning of PSCX 2.0 Initialization --------------------

Import-Module Pscx

# Import the Pscx.Deprecated module only if you need PSCX's Start-Process, 
# Select-Xml and Get-Random cmdlets instead of PowerShell's built-in version
# of these cmdlets.
#Import-Module Pscx.Deprecated 

#endregion -------- End of PSCX 2.0 Initialization --------------------------
